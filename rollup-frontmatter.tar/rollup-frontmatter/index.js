/**
 * @typedef {import('./lib/index.js').Options} Options
 */

export {rollup as default} from './lib/index.js'
