export { rollup as default } from "./lib/index.js";
export type Options = import('./lib/index.js').Options;
